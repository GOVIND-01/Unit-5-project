import './App.css';
import {Groceries } from './components/Groceries';
function App() {
  return (
    <div id="container">
     
      <div className="App">
        <Groceries />
      </div>
    </div>
  );
}

export default App;
